import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

// 🔥 CLEAN TOKEN ON APP STARTUP
const token = localStorage.getItem('token');
if (token) {
  const cleanToken = token.replace(/\s/g, '');
  if (cleanToken !== token) {
    localStorage.setItem('token', cleanToken);
    console.log('🧹 Token cleaned on startup!');
    console.log('📏 Old length:', token.length, 'New length:', cleanToken.length);
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);